---
name: gripper-control
description: Control the serial gripper over ROS2. Use when the user asks to open the gripper, close the gripper, move it to a target angle, or check the current gripper angle/state. Also use for Chinese requests such as 打开夹爪, 张开夹爪, 闭合夹爪, 合拢夹爪, 把夹爪调到 -20 度, 夹爪张开到 30 度, 查询夹爪状态, 当前夹爪角度是多少. Publish serial_servo_bridge/msg/ServoCommand to /servo/command and read serial_servo_bridge/msg/ServoStatus from /servo/status.
---

# Gripper Control

Use this skill when the user asks things like:

- 打开夹爪
- 张开夹爪
- 闭合夹爪
- 合拢夹爪
- 夹爪张开到 30 度
- 把夹爪调到 -20 度
- 查询夹爪状态
- 当前夹爪角度是多少

## ROS2 Interface

- Command topic: `/servo/command`
- Command type: `serial_servo_bridge/msg/ServoCommand`
- Status topic: `/servo/status`
- Status type: `serial_servo_bridge/msg/ServoStatus`
- Raw status fallback topic: `/servo/status_raw`
- Raw status fallback type: `std_msgs/msg/String`

## Robot-Specific Truth

- This gripper uses the range `[-70.0, 0.0]`
- `0.0` means fully closed / minimum opening
- `-70.0` means fully open / maximum opening
- A more negative value means the gripper is more open
- Therefore:
  - `打开夹爪` means send a negative value such as `-65.0`
  - `闭合夹爪` means send `0.0`
- Never interpret `打开夹爪` as `+30`, `+65`, or any other positive angle
- Never interpret `打开夹爪` as `0.0`
- Never interpret `闭合夹爪` as `-65.0`

## Command Rules

- Only use position mode for this skill: `mode: 0`
- Always use `servo_id: 1`
- Valid angle range is `[-70.0, 0.0]`
- Never publish a positive position value for this robot
- Never use `{command: "open"}` or `{command: "close"}` for this robot
- Always send the explicit ServoCommand payload `{mode, servo_id, value}`
- Positive values such as `+10`, `+30`, or `+65` are invalid and will be ignored by the ROS2 bridge
- For this robot, a more negative angle means the gripper is more open
- Use these fixed mappings unless the user explicitly requests another angle:
  - `打开夹爪` / `张开夹爪` / `松开夹爪` -> `value: -65.0`
  - `闭合夹爪` / `合拢夹爪` / `夹紧夹爪` -> `value: 0.0`
- Do not infer that closing is the opposite of opening
- Do not mirror `-65.0` into `+65.0`
- If the user asks to close the gripper without giving a specific angle, always send `0.0`

## Angle Interpretation

When the user provides a target angle:

- If the user gives an explicit signed angle such as `-30` or `0`, use that value directly
- If the user says `张开到 30 度` or `打开到 30 度` without a minus sign, interpret it as opening magnitude and publish `value: -30.0`
- Clamp any final angle to `[-70.0, 0.0]`
- If the user gives a positive target angle for position control, do not publish that positive value; clamp it to `0.0` and tell the user the request was adjusted to the valid range
- If clamping was applied, tell the user what value was actually sent

## How To Execute

### 1. Open the gripper

Use `ros2_publish` with:

```json
{
  "topic": "/servo/command",
  "type": "serial_servo_bridge/msg/ServoCommand",
  "message": {
    "mode": 0,
    "servo_id": 1,
    "value": -65.0
  }
}
```

Do not replace this with `{command:"open"}`.
Do not replace this with a positive angle.

### 2. Close the gripper

Use `ros2_publish` with:

```json
{
  "topic": "/servo/command",
  "type": "serial_servo_bridge/msg/ServoCommand",
  "message": {
    "mode": 0,
    "servo_id": 1,
    "value": 0.0
  }
}
```

Do not replace this with `{command:"close"}`.

### 3. Move to a target angle

Use `ros2_publish` with:

```json
{
  "topic": "/servo/command",
  "type": "serial_servo_bridge/msg/ServoCommand",
  "message": {
    "mode": 0,
    "servo_id": 1,
    "value": <final_angle_deg>
  }
}
```

Replace `<final_angle_deg>` with the interpreted and clamped angle.

## Status Query

When the user asks for current angle, current state, or whether the gripper is reporting status, use `ros2_subscribe_once` on `/servo/status`.

Preferred tool call:

```json
{
  "topic": "/servo/status",
  "type": "serial_servo_bridge/msg/ServoStatus",
  "timeout": 4000
}
```

Interpret the result as follows:

- `parsed: true` means the status line was parsed successfully
- `value` is the current hardware angle in degrees
- `servo_id` should normally be `1`
- `mode: 0` means position status
- `raw` contains the original serial line

If `/servo/status` times out, fall back to `/servo/status_raw`:

```json
{
  "topic": "/servo/status_raw",
  "type": "std_msgs/msg/String",
  "timeout": 3000
}
```

If both queries fail, say that no fresh gripper feedback was received and avoid claiming the current angle.

## Command Confirmation

After any position command to open, close, or move to a target angle, immediately verify feedback before claiming success.

1. Publish the command to `/servo/command`
2. Then call `ros2_subscribe_once` on `/servo/status` with type `serial_servo_bridge/msg/ServoStatus`
3. If `parsed: true` and the returned `value` is within about `3.0` degrees of the requested target, you may confirm the gripper reached the requested angle
4. If a status message arrives but the angle is still far from the requested target, say the command was sent but the target angle was not confirmed
5. If no fresh status message arrives, say the command was sent but execution could not be confirmed

Never say `已调整到 ...` or `状态正常` based only on the `ros2_publish` tool result.

## Response Style

- For command requests, state the exact angle that was sent
- For angle requests, report the current angle in degrees
- If a user request was ambiguous and you had to convert `30 度` to `-30.0`, say so explicitly
- Never claim that `+65.0` or any other positive position angle was sent for this gripper
- Never claim motion success from `ros2_publish` alone
- Do not mention unrelated robot topics or navigation tools
- Do not use speed mode in this skill
- If the tool result shows a sent value different from the intended target, explicitly report the actual sent value

## Examples

User: `打开夹爪`
Action: publish `value: -65.0`
Reply: `已发送夹爪张开命令，目标角度 -65.0 度。`

User: `闭合夹爪`
Action: publish `value: 0.0`
Reply: `已发送夹爪闭合命令，目标角度 0.0 度。`

User: `夹爪张开到 30 度`
Action: publish `value: -30.0`
Reply: `已发送夹爪控制命令。根据“张开到 30 度”，实际发送角度为 -30.0 度。`

User: `当前夹爪角度是多少`
Action: read `/servo/status`
Reply: `当前夹爪角度约为 -29.8 度。`

User: `把夹爪调到 -20 度`
Action: publish `value: -20.0`, then read `/servo/status`
Reply if confirmed: `已发送夹爪控制命令，目标角度 -20.0 度。当前反馈角度约为 -19.6 度。`
Reply if not confirmed: `已发送夹爪控制命令，目标角度 -20.0 度，但暂未从 /servo/status 确认夹爪已到位。`
