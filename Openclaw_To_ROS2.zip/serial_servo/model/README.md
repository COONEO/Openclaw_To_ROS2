# model

机械夹爪 URDF 与 RViz 可视化启动文件。

## 构建

```bash
cd /home/kuniu/serial_servo
colcon build --packages-select model
source install/setup.bash
```

## 启动 RViz 可视化

```bash
ros2 launch model display_gripper.launch.py
```

可选参数：

```bash
ros2 launch model display_gripper.launch.py use_joint_state_gui:=false
```
