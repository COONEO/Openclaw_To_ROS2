from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def _launch_setup(context, *_args):
    urdf_model = LaunchConfiguration("urdf_model").perform(context)
    rviz_config = LaunchConfiguration("rviz_config").perform(context)
    use_joint_state_publisher = LaunchConfiguration("use_joint_state_publisher").perform(context).lower()
    use_joint_state_gui = LaunchConfiguration("use_joint_state_gui").perform(context).lower()

    with open(urdf_model, "r", encoding="utf-8") as urdf_file:
        robot_description = urdf_file.read()

    joint_state_pkg = "joint_state_publisher_gui" if use_joint_state_gui in ("true", "1", "yes", "on") else "joint_state_publisher"
    joint_state_exe = "joint_state_publisher_gui" if joint_state_pkg == "joint_state_publisher_gui" else "joint_state_publisher"

    launch_nodes = []
    if use_joint_state_publisher in ("true", "1", "yes", "on"):
        launch_nodes.append(
            Node(
                package=joint_state_pkg,
                executable=joint_state_exe,
                name="joint_state_publisher",
                output="screen",
                parameters=[{"use_mimic_tags": True}],
            )
        )

    launch_nodes.extend(
        [
            Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            name="robot_state_publisher",
            output="screen",
            parameters=[{"robot_description": robot_description}],
        ),
            Node(
            package="rviz2",
            executable="rviz2",
            name="rviz2",
            output="screen",
            arguments=["-d", rviz_config],
        ),
        ]
    )

    return launch_nodes


def generate_launch_description() -> LaunchDescription:
    default_urdf_model = PathJoinSubstitution([FindPackageShare("model"), "src", "gripper.urdf"])
    default_rviz_config = PathJoinSubstitution([FindPackageShare("model"), "launch", "gripper.rviz"])

    return LaunchDescription(
        [
            DeclareLaunchArgument("urdf_model", default_value=default_urdf_model),
            DeclareLaunchArgument("rviz_config", default_value=default_rviz_config),
            DeclareLaunchArgument("use_joint_state_publisher", default_value="false"),
            DeclareLaunchArgument("use_joint_state_gui", default_value="true"),
            OpaqueFunction(function=_launch_setup),
        ]
    )
