from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def _launch_setup(context, *_args):
    urdf_model = LaunchConfiguration("urdf_model").perform(context)

    with open(urdf_model, "r", encoding="utf-8") as urdf_file:
        robot_description = urdf_file.read()

    launch_nodes = []

    if LaunchConfiguration("start_robot_state_publisher").perform(context).lower() in ("true", "1", "yes", "on"):
        launch_nodes.append(
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                name="robot_state_publisher",
                output="screen",
                parameters=[{"robot_description": robot_description}],
            )
        )

    launch_nodes.append(
        Node(
            package="serial_servo_app",
            executable="serial_servo_control_app",
            output="screen",
            arguments=[
                "--ros-args",
                "--log-level",
                "rviz_common:=warn",
                "--log-level",
                "rviz_rendering:=warn",
            ],
            parameters=[
                {
                    "command_topic": LaunchConfiguration("command_topic"),
                    "status_topic": LaunchConfiguration("status_topic"),
                    "connect_service": LaunchConfiguration("connect_service"),
                    "disconnect_service": LaunchConfiguration("disconnect_service"),
                    "servo_id": LaunchConfiguration("servo_id"),
                    "min_angle_deg": LaunchConfiguration("min_angle_deg"),
                    "max_angle_deg": LaunchConfiguration("max_angle_deg"),
                    "initial_angle_deg": LaunchConfiguration("initial_angle_deg"),
                    "feedback_timeout_sec": LaunchConfiguration("feedback_timeout_sec"),
                }
            ],
        )
    )

    return launch_nodes


def generate_launch_description() -> LaunchDescription:
    serial_bridge_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [FindPackageShare("serial_servo_bridge"), "launch", "serial_servo_bridge.launch.py"]
            )
        ),
        condition=IfCondition(LaunchConfiguration("start_serial_bridge")),
        launch_arguments={
            "port": LaunchConfiguration("port"),
            "baud_rate": LaunchConfiguration("baud_rate"),
            "connect_service": LaunchConfiguration("connect_service"),
            "disconnect_service": LaunchConfiguration("disconnect_service"),
            "pos_min_deg": LaunchConfiguration("min_angle_deg"),
            "pos_max_deg": LaunchConfiguration("max_angle_deg"),
            "enable_status_joint_state_bridge": "true",
            "target_servo_id": LaunchConfiguration("servo_id"),
            "hardware_min_deg": LaunchConfiguration("min_angle_deg"),
            "hardware_max_deg": LaunchConfiguration("max_angle_deg"),
        }.items(),
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("start_serial_bridge", default_value="true"),
            DeclareLaunchArgument("start_robot_state_publisher", default_value="true"),
            DeclareLaunchArgument("port", default_value="/dev/ttyUSB0"),
            DeclareLaunchArgument("baud_rate", default_value="115200"),
            DeclareLaunchArgument("command_topic", default_value="servo/command"),
            DeclareLaunchArgument("status_topic", default_value="servo/status"),
            DeclareLaunchArgument("connect_service", default_value="servo/connect"),
            DeclareLaunchArgument("disconnect_service", default_value="servo/disconnect"),
            DeclareLaunchArgument("servo_id", default_value="1"),
            DeclareLaunchArgument("min_angle_deg", default_value="-70.0"),
            DeclareLaunchArgument("max_angle_deg", default_value="0.0"),
            DeclareLaunchArgument("initial_angle_deg", default_value="0.0"),
            DeclareLaunchArgument("feedback_timeout_sec", default_value="1.2"),
            DeclareLaunchArgument(
                "urdf_model",
                default_value=PathJoinSubstitution([FindPackageShare("model"), "src", "gripper.urdf"]),
            ),
            serial_bridge_launch,
            OpaqueFunction(function=_launch_setup),
        ]
    )
