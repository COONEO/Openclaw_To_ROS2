#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <limits>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include <QApplication>
#include <QDateTime>
#include <QDockWidget>
#include <QDoubleSpinBox>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QLabel>
#include <QMenuBar>
#include <QPushButton>
#include <QSignalBlocker>
#include <QSlider>
#include <QStatusBar>
#include <QStyle>
#include <QToolBar>
#include <QTimer>
#include <QVBoxLayout>
#include <QWidget>

#include "rclcpp/rclcpp.hpp"
#include "rviz_common/display.hpp"
#include "rviz_common/properties/property.hpp"
#include "rviz_common/ros_integration/ros_node_abstraction.hpp"
#include "rviz_common/visualization_frame.hpp"
#include "rviz_common/visualization_manager.hpp"
#include "serial_servo_bridge/msg/servo_command.hpp"
#include "serial_servo_bridge/msg/servo_status.hpp"
#include "std_srvs/srv/trigger.hpp"

namespace
{
constexpr int kSliderScale = 10;  // 0.1 deg resolution.
constexpr std::chrono::milliseconds kUiTickPeriod{20};

QString toAngleText(const double angle_deg)
{
  return QString::number(angle_deg, 'f', 1) + QStringLiteral(" deg");
}

}  // namespace

class ServoControlWindow : public rviz_common::VisualizationFrame
{
public:
  ServoControlWindow(
    const rclcpp::Node::SharedPtr & node,
    const std::shared_ptr<rclcpp::executors::SingleThreadedExecutor> & executor,
    const std::shared_ptr<rviz_common::ros_integration::RosNodeAbstraction> & rviz_ros_node)
  : rviz_common::VisualizationFrame(rviz_ros_node),
    node_(node),
    executor_(executor),
    rviz_ros_node_(rviz_ros_node)
  {
    loadParameters();

    setWindowTitle("Serial Servo Control");
    resize(1500, 920);
    setSplashPath("");
    if (auto * qt_app = qobject_cast<QApplication *>(QApplication::instance())) {
      setApp(qt_app);
    }
    initialize(rviz_ros_node_);

    setupRvizDisplays();
    hideDefaultRvizChrome();
    buildControlDock();
    applyTheme();

    createRosInterfaces();
    wireSignals();
    setTargetAngle(initial_angle_deg_);
    updateConnectionBadge();
    startRosSpinThread();

    ui_timer_ = new QTimer(this);
    ui_timer_->setInterval(static_cast<int>(kUiTickPeriod.count()));
    connect(ui_timer_, &QTimer::timeout, this, [this]() {
      syncUiFromRosState();
      updateConnectionBadge();
    });
    ui_timer_->start();

    RCLCPP_INFO(node_->get_logger(), "Serial Servo app started.");
  }

  ~ServoControlWindow() override
  {
    stopRosSpinThread();
  }

private:
  enum class Source
  {
    kInternal,
    kSlider,
    kSpinBox,
  };

  void loadParameters()
  {
    command_topic_ = node_->declare_parameter<std::string>("command_topic", "servo/command");
    status_topic_ = node_->declare_parameter<std::string>("status_topic", "servo/status");
    connect_service_ = node_->declare_parameter<std::string>("connect_service", "servo/connect");
    disconnect_service_ = node_->declare_parameter<std::string>("disconnect_service", "servo/disconnect");
    servo_id_ = node_->declare_parameter<int>("servo_id", 1);
    min_angle_deg_ = node_->declare_parameter<double>("min_angle_deg", -70.0);
    max_angle_deg_ = node_->declare_parameter<double>("max_angle_deg", 0.0);
    initial_angle_deg_ = node_->declare_parameter<double>("initial_angle_deg", 0.0);
    feedback_timeout_sec_ = node_->declare_parameter<double>("feedback_timeout_sec", 1.2);

    if (min_angle_deg_ > max_angle_deg_) {
      std::swap(min_angle_deg_, max_angle_deg_);
      RCLCPP_WARN(
        node_->get_logger(), "min_angle_deg > max_angle_deg, swapped. range=[%.3f, %.3f]",
        min_angle_deg_, max_angle_deg_);
    }
    initial_angle_deg_ = clampAngle(initial_angle_deg_);
  }

  void setupRvizDisplays()
  {
    auto * manager = getManager();
    if (manager == nullptr) {
      RCLCPP_WARN(node_->get_logger(), "RViz manager is null.");
      return;
    }

    manager->removeAllDisplays();
    manager->setFixedFrame("base_link");

    auto * grid_display = manager->createDisplay("rviz_default_plugins/Grid", "Grid", true);
    if (grid_display != nullptr) {
      if (auto * cell_size = grid_display->subProp("Cell Size")) {
        cell_size->setValue(0.1);
      }
      if (auto * plane_count = grid_display->subProp("Plane Cell Count")) {
        plane_count->setValue(20);
      }
    }

    auto * robot_model_display = manager->createDisplay(
      "rviz_default_plugins/RobotModel", "RobotModel", true);
    if (robot_model_display == nullptr) {
      RCLCPP_WARN(node_->get_logger(), "Failed to create RobotModel display.");
      return;
    }

    if (auto * desc_source = robot_model_display->subProp("Description Source")) {
      desc_source->setValue("Topic");
    }
    if (auto * desc_topic = robot_model_display->subProp("Description Topic")) {
      desc_topic->setValue("/robot_description");
    }
    if (auto * visual_enabled = robot_model_display->subProp("Visual Enabled")) {
      visual_enabled->setValue(true);
    }
    if (auto * collision_enabled = robot_model_display->subProp("Collision Enabled")) {
      collision_enabled->setValue(false);
    }
  }

  void hideDefaultRvizChrome()
  {
    if (menuBar() != nullptr) {
      menuBar()->hide();
    }
    if (statusBar() != nullptr) {
      statusBar()->hide();
    }
    for (auto * tool_bar : findChildren<QToolBar *>()) {
      tool_bar->hide();
    }
    for (auto * dock : findChildren<QDockWidget *>()) {
      dock->hide();
    }
    setHideButtonVisibility(false);
  }

  void buildControlDock()
  {
    control_dock_ = new QDockWidget("Control", this);
    control_dock_->setObjectName("controlDock");
    control_dock_->setFeatures(QDockWidget::NoDockWidgetFeatures);
    control_dock_->setAllowedAreas(Qt::RightDockWidgetArea);

    auto * dock_content = new QWidget(control_dock_);
    auto * right_layout = new QVBoxLayout(dock_content);
    right_layout->setContentsMargins(14, 14, 14, 14);
    right_layout->setSpacing(12);

    auto * status_group = new QGroupBox("Status", dock_content);
    auto * status_layout = new QVBoxLayout(status_group);
    status_layout->setContentsMargins(10, 10, 10, 10);
    status_layout->setSpacing(8);

    connection_badge_ = new QLabel("Waiting feedback", status_group);
    connection_badge_->setObjectName("badgeOffline");

    feedback_value_label_ = new QLabel("--", status_group);
    feedback_value_label_->setObjectName("value");

    parsed_label_ = new QLabel("--", status_group);
    parsed_label_->setObjectName("subtle");

    serial_toggle_button_ = new QPushButton(status_group);
    serial_toggle_button_->setObjectName("secondaryButton");
    updateSerialToggleButton();

    status_layout->addWidget(connection_badge_);
    status_layout->addWidget(new QLabel("Current angle", status_group));
    status_layout->addWidget(feedback_value_label_);
    status_layout->addWidget(parsed_label_);
    status_layout->addWidget(serial_toggle_button_);

    auto * control_group = new QGroupBox("Position Control", dock_content);
    auto * control_layout = new QVBoxLayout(control_group);
    control_layout->setContentsMargins(10, 10, 10, 10);
    control_layout->setSpacing(10);

    angle_spin_box_ = new QDoubleSpinBox(control_group);
    angle_spin_box_->setRange(min_angle_deg_, max_angle_deg_);
    angle_spin_box_->setDecimals(1);
    angle_spin_box_->setSingleStep(0.1);
    angle_spin_box_->setSuffix(" deg");

    angle_slider_ = new QSlider(Qt::Horizontal, control_group);
    angle_slider_->setRange(angleToSlider(min_angle_deg_), angleToSlider(max_angle_deg_));
    angle_slider_->setSingleStep(1);
    angle_slider_->setPageStep(5);

    target_value_label_ = new QLabel("Target: --", control_group);
    target_value_label_->setObjectName("value");

    send_button_ = new QPushButton("Send Position", control_group);
    send_button_->setObjectName("primaryButton");

    reset_button_ = new QPushButton("Reset To Initial", control_group);
    reset_button_->setObjectName("secondaryButton");

    last_command_label_ = new QLabel("Last command: none", control_group);
    last_command_label_->setObjectName("subtle");

    control_layout->addWidget(angle_spin_box_);
    control_layout->addWidget(angle_slider_);
    control_layout->addWidget(target_value_label_);
    control_layout->addWidget(send_button_);
    control_layout->addWidget(reset_button_);
    control_layout->addWidget(last_command_label_);

    right_layout->addWidget(status_group);
    right_layout->addWidget(control_group);
    right_layout->addStretch(1);

    control_dock_->setWidget(dock_content);
    addDockWidget(Qt::RightDockWidgetArea, control_dock_);
    control_dock_->show();
    control_dock_->setMinimumWidth(360);
    control_dock_->setMaximumWidth(420);
  }

  void createRosInterfaces()
  {
    const auto latest_only_qos = rclcpp::QoS(rclcpp::KeepLast(1));

    command_pub_ = node_->create_publisher<serial_servo_bridge::msg::ServoCommand>(
      command_topic_, latest_only_qos);
    connect_client_ = node_->create_client<std_srvs::srv::Trigger>(connect_service_);
    disconnect_client_ = node_->create_client<std_srvs::srv::Trigger>(disconnect_service_);

    status_sub_ = node_->create_subscription<serial_servo_bridge::msg::ServoStatus>(
      status_topic_, latest_only_qos,
      [this](const serial_servo_bridge::msg::ServoStatus::SharedPtr msg) {
        if (msg->servo_id != static_cast<uint16_t>(servo_id_)) {
          return;
        }

        std::lock_guard<std::mutex> lock(state_mutex_);
        feedback_angle_deg_ = clampAngle(static_cast<double>(msg->value));
        has_feedback_ = true;
        feedback_parsed_ = msg->parsed;
        last_feedback_wall_time_ = std::chrono::steady_clock::now();
        feedback_dirty_ = true;
      });
  }

  void wireSignals()
  {
    connect(angle_slider_, &QSlider::valueChanged, this, [this](const int slider_value) {
      setTargetAngle(sliderToAngle(slider_value), Source::kSlider);
    });

    connect(
      angle_spin_box_,
      qOverload<double>(&QDoubleSpinBox::valueChanged),
      this,
      [this](const double value) {
        setTargetAngle(value, Source::kSpinBox);
      });

    connect(send_button_, &QPushButton::clicked, this, [this]() {
      publishPosition(target_angle_deg_);
    });

    connect(reset_button_, &QPushButton::clicked, this, [this]() {
      setTargetAngle(initial_angle_deg_);
      publishPosition(initial_angle_deg_);
    });

    connect(serial_toggle_button_, &QPushButton::clicked, this, [this]() {
      toggleSerialConnection();
    });
  }

  void applyTheme()
  {
    setStyleSheet(
      "QMainWindow { background: #edf1f5; color: #1f2937; }"
      "QDockWidget#controlDock {"
      "  background: #ffffff;"
      "  border-left: 1px solid #d8e2ec;"
      "}"
      "QGroupBox {"
      "  font-weight: 600;"
      "  border: 1px solid #d6dee8;"
      "  border-radius: 10px;"
      "  margin-top: 8px;"
      "  background: #ffffff;"
      "}"
      "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }"
      "QPushButton {"
      "  min-height: 34px;"
      "  border-radius: 8px;"
      "  border: 1px solid #cad5e2;"
      "  padding: 4px 10px;"
      "}"
      "QPushButton#primaryButton {"
      "  background: #1f7a8c;"
      "  color: #ffffff;"
      "  border: 1px solid #176272;"
      "}"
      "QPushButton#primaryButton:hover { background: #176272; }"
      "QPushButton#secondaryButton { background: #f8fbff; }"
      "QLineEdit, QDoubleSpinBox {"
      "  min-height: 30px;"
      "  border-radius: 8px;"
      "  border: 1px solid #cad5e2;"
      "  padding: 2px 8px;"
      "  background: #ffffff;"
      "}"
      "QLabel#value { font-size: 18px; font-weight: 700; color: #1e3a5f; }"
      "QLabel#subtle { color: #5f6f82; }"
      "QLabel#badgeOnline {"
      "  color: #1b5e20;"
      "  background: #e6f4ea;"
      "  border: 1px solid #b7dfc0;"
      "  border-radius: 9px;"
      "  padding: 4px 8px;"
      "  font-weight: 600;"
      "}"
      "QLabel#badgeOffline {"
      "  color: #8a4b00;"
      "  background: #fff4e5;"
      "  border: 1px solid #ffd6a7;"
      "  border-radius: 9px;"
      "  padding: 4px 8px;"
      "  font-weight: 600;"
      "}");
  }

  void updateSerialToggleButton()
  {
    if (serial_toggle_button_ == nullptr) {
      return;
    }

    if (serial_connected_requested_) {
      serial_toggle_button_->setText("Disconnect Serial");
    } else {
      serial_toggle_button_->setText("Connect Serial");
    }
  }

  void startRosSpinThread()
  {
    ros_spin_running_.store(true);
    ros_spin_thread_ = std::thread([this]() {
      while (ros_spin_running_.load() && rclcpp::ok()) {
        executor_->spin_some(std::chrono::milliseconds(5));
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
      }
    });
  }

  void stopRosSpinThread()
  {
    ros_spin_running_.store(false);
    if (ros_spin_thread_.joinable()) {
      ros_spin_thread_.join();
    }
  }

  void syncUiFromRosState()
  {
    bool has_feedback_update = false;
    double feedback_angle_deg = std::numeric_limits<double>::quiet_NaN();
    bool feedback_parsed = false;

    bool has_serial_toggle_response = false;
    bool serial_toggle_success = false;
    bool serial_toggle_requested_connect = false;
    std::string serial_toggle_message;

    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      if (feedback_dirty_) {
        has_feedback_update = true;
        feedback_angle_deg = feedback_angle_deg_;
        feedback_parsed = feedback_parsed_;
        feedback_dirty_ = false;
      }
      if (serial_toggle_response_pending_) {
        has_serial_toggle_response = true;
        serial_toggle_success = serial_toggle_response_success_;
        serial_toggle_requested_connect = serial_toggle_response_requested_connect_;
        serial_toggle_message = serial_toggle_response_message_;
        serial_toggle_response_pending_ = false;
      }
    }

    if (has_feedback_update) {
      if (feedback_value_label_ != nullptr) {
        feedback_value_label_->setText(toAngleText(feedback_angle_deg));
      }
      if (parsed_label_ != nullptr) {
        parsed_label_->setText(feedback_parsed ? QStringLiteral("parsed") : QStringLiteral("raw"));
      }
    }

    if (has_serial_toggle_response) {
      if (serial_toggle_success) {
        serial_connected_requested_ = serial_toggle_requested_connect;
        updateSerialToggleButton();
      }
      const std::string fallback_message = serial_toggle_requested_connect ?
        "Serial connect requested." : "Serial disconnect requested.";
      const auto & message = serial_toggle_message.empty() ? fallback_message : serial_toggle_message;
      last_command_label_->setText(QString::fromStdString(message));
      serial_toggle_button_->setEnabled(true);
    }
  }

  void toggleSerialConnection()
  {
    const bool request_connect = !serial_connected_requested_;
    auto client =
      request_connect ? connect_client_ : disconnect_client_;

    if (client == nullptr || !client->wait_for_service(std::chrono::milliseconds(200))) {
      last_command_label_->setText("Serial service unavailable");
      return;
    }

    serial_toggle_button_->setEnabled(false);
    serial_toggle_button_->setText(request_connect ? "Connecting..." : "Disconnecting...");

    auto request = std::make_shared<std_srvs::srv::Trigger::Request>();
    client->async_send_request(
      request,
      [this, request_connect](rclcpp::Client<std_srvs::srv::Trigger>::SharedFuture future) {
        const auto response = future.get();
        std::lock_guard<std::mutex> lock(state_mutex_);
        serial_toggle_response_pending_ = true;
        serial_toggle_response_success_ = response->success;
        serial_toggle_response_requested_connect_ = request_connect;
        serial_toggle_response_message_ = response->message;
      });
  }

  void setTargetAngle(const double requested_angle_deg, const Source source = Source::kInternal)
  {
    target_angle_deg_ = clampAngle(requested_angle_deg);

    if (source != Source::kSlider) {
      const QSignalBlocker blocker(angle_slider_);
      angle_slider_->setValue(angleToSlider(target_angle_deg_));
    }
    if (source != Source::kSpinBox) {
      const QSignalBlocker blocker(angle_spin_box_);
      angle_spin_box_->setValue(target_angle_deg_);
    }

    target_value_label_->setText("Target: " + toAngleText(target_angle_deg_));
  }

  void publishPosition(const double requested_angle_deg)
  {
    const double cmd_angle_deg = clampAngle(requested_angle_deg);

    serial_servo_bridge::msg::ServoCommand command_msg;
    command_msg.mode = serial_servo_bridge::msg::ServoCommand::MODE_POS;
    command_msg.servo_id = static_cast<uint16_t>(std::max(0, servo_id_));
    command_msg.value = static_cast<float>(cmd_angle_deg);
    command_pub_->publish(command_msg);

    const auto now = QDateTime::currentDateTime().toString("HH:mm:ss");
    last_command_label_->setText("Last command: " + toAngleText(cmd_angle_deg) + " @ " + now);
  }

  void updateConnectionBadge()
  {
    bool has_feedback = false;
    std::chrono::steady_clock::time_point last_feedback_wall_time;
    {
      std::lock_guard<std::mutex> lock(state_mutex_);
      has_feedback = has_feedback_;
      last_feedback_wall_time = last_feedback_wall_time_;
    }

    const auto now = std::chrono::steady_clock::now();
    const bool online =
      has_feedback &&
      (now - last_feedback_wall_time <= std::chrono::duration<double>(feedback_timeout_sec_));

    if (online) {
      connection_badge_->setText("Hardware online");
      connection_badge_->setObjectName("badgeOnline");
    } else {
      connection_badge_->setText("Waiting feedback");
      connection_badge_->setObjectName("badgeOffline");
    }

    connection_badge_->style()->unpolish(connection_badge_);
    connection_badge_->style()->polish(connection_badge_);
  }

  double clampAngle(const double angle_deg) const
  {
    return std::clamp(angle_deg, min_angle_deg_, max_angle_deg_);
  }

  int angleToSlider(const double angle_deg) const
  {
    return static_cast<int>(std::lround(angle_deg * static_cast<double>(kSliderScale)));
  }

  double sliderToAngle(const int slider_value) const
  {
    return static_cast<double>(slider_value) / static_cast<double>(kSliderScale);
  }

  rclcpp::Node::SharedPtr node_;
  std::shared_ptr<rclcpp::executors::SingleThreadedExecutor> executor_;
  std::shared_ptr<rviz_common::ros_integration::RosNodeAbstraction> rviz_ros_node_;

  std::string command_topic_;
  std::string status_topic_;
  std::string connect_service_;
  std::string disconnect_service_;

  int servo_id_{1};
  double min_angle_deg_{-70.0};
  double max_angle_deg_{0.0};
  double initial_angle_deg_{0.0};
  double feedback_timeout_sec_{1.2};

  double target_angle_deg_{0.0};
  std::mutex state_mutex_;
  double feedback_angle_deg_{std::numeric_limits<double>::quiet_NaN()};
  bool has_feedback_{false};
  bool feedback_parsed_{false};
  bool feedback_dirty_{false};
  bool serial_connected_requested_{true};
  std::chrono::steady_clock::time_point last_feedback_wall_time_{};
  bool serial_toggle_response_pending_{false};
  bool serial_toggle_response_success_{false};
  bool serial_toggle_response_requested_connect_{false};
  std::string serial_toggle_response_message_;
  std::atomic<bool> ros_spin_running_{false};
  std::thread ros_spin_thread_;

  rclcpp::Publisher<serial_servo_bridge::msg::ServoCommand>::SharedPtr command_pub_;
  rclcpp::Subscription<serial_servo_bridge::msg::ServoStatus>::SharedPtr status_sub_;
  rclcpp::Client<std_srvs::srv::Trigger>::SharedPtr connect_client_;
  rclcpp::Client<std_srvs::srv::Trigger>::SharedPtr disconnect_client_;

  QDockWidget * control_dock_{nullptr};

  QLabel * connection_badge_{nullptr};
  QLabel * feedback_value_label_{nullptr};
  QLabel * parsed_label_{nullptr};
  QLabel * target_value_label_{nullptr};
  QLabel * last_command_label_{nullptr};
  QPushButton * serial_toggle_button_{nullptr};

  QDoubleSpinBox * angle_spin_box_{nullptr};
  QSlider * angle_slider_{nullptr};
  QPushButton * send_button_{nullptr};
  QPushButton * reset_button_{nullptr};

  QTimer * ui_timer_{nullptr};
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  QApplication app(argc, argv);

  auto control_node = std::make_shared<rclcpp::Node>("serial_servo_control_app");
  auto executor = std::make_shared<rclcpp::executors::SingleThreadedExecutor>();
  executor->add_node(control_node);

  auto rviz_node =
    std::make_shared<rviz_common::ros_integration::RosNodeAbstraction>("serial_servo_app_rviz");

  int exit_code = 0;
  {
    ServoControlWindow window(control_node, executor, rviz_node);
    window.show();
    exit_code = app.exec();
  }

  executor->remove_node(control_node);
  rclcpp::shutdown();
  return exit_code;
}
