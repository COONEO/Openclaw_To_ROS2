# serial_servo_app

Qt desktop app with embedded RViz for real-time gripper control and visualization.

## Features

- Embedded 3D visualization (RViz renderer) with the same URDF/RViz config as your current model.
- Real-time hardware feedback status from `servo/status`.
- Position-only control (single-shot command publish).
- UI controls: input box, spin box, slider, send button, reset button.
- One-command bringup launch (serial bridge + status bridge + robot_state_publisher + app).

## Build

```bash
cd /home/kuniu/serial_servo
source /opt/ros/humble/setup.bash
colcon build --packages-select serial_servo_app
source install/setup.bash
```

## Run Full App

```bash
ros2 launch serial_servo_app serial_servo_control_app.launch.py port:=/dev/ttyUSB0 baud_rate:=115200
```

## Optional Run Modes

Run only the app UI (skip serial bridge):

```bash
ros2 launch serial_servo_app serial_servo_control_app.launch.py start_serial_bridge:=false
```

## Executable Output

After build, the app binary is:

```bash
/home/kuniu/serial_servo/install/serial_servo_app/lib/serial_servo_app/serial_servo_control_app
```

You can run it directly (after sourcing ROS and workspace setup):

```bash
source /opt/ros/humble/setup.bash
source /home/kuniu/serial_servo/install/setup.bash
/home/kuniu/serial_servo/install/serial_servo_app/lib/serial_servo_app/serial_servo_control_app
```
