# serial_servo_bridge

ROS 2 Humble C++ 功能包，用于和 STM32(F407VET6) 通过串口持续通信：

- 订阅控制话题 `servo/command`
- 转换为 AT 指令并发送到串口（`AT+Pos` / `AT+Speed`）
- 持续接收 STM32 串口数据并发布到 `servo/status` 与 `servo/status_raw`

## 1. 指令格式

发送格式：

- `AT+Pos,<servo_id>,<angle>\n`
- `AT+Speed,<servo_id>,<speed>\n`

接收格式（单片机回传）：

- `AT+Angle,<servo_id>,<angle>\n`

示例：

- `AT+Pos,1,-30.0\n`
- `AT+Speed,1,3.0\n`

注意：`'\n'` 结尾是必须的（例如 `AT+Pos,1,-30.0\n`），否则舵机侧可能不执行指令。

## 2. 构建

```bash
cd /home/kuniu/serial_servo
colcon build --packages-select serial_servo_bridge
source install/setup.bash
```

## 3. 运行

```bash
ros2 run serial_servo_bridge serial_servo_bridge_node --ros-args --params-file serial_servo_bridge/config/serial_servo_bridge.yaml
```

仅启动状态到关节桥接（用于 `/servo/status -> /joint_states`）：

```bash
ros2 run serial_servo_bridge status_to_joint_state_bridge_node --ros-args --params-file serial_servo_bridge/config/serial_servo_bridge.yaml
```

或使用 launch：

```bash
ros2 launch serial_servo_bridge serial_servo_bridge.launch.py port:=/dev/ttyUSB0 baud_rate:=115200
```

按需覆盖限位参数：

```bash
ros2 launch serial_servo_bridge serial_servo_bridge.launch.py \
  port:=/dev/ttyUSB0 baud_rate:=115200 \
  pos_min_deg:=-70.0 pos_max_deg:=0.0 speed_min:=-5.0 speed_max:=5.0
```

默认会同时启动 `status_to_joint_state_bridge_node`，把 `/servo/status` 映射到 `/joint_states`。

## 4. 发送控制命令

位置控制：

```bash
ros2 topic pub --once /servo/command serial_servo_bridge/msg/ServoCommand "{mode: 0, servo_id: 1, value: -30.0}"
```

速度控制：

```bash
ros2 topic pub --once /servo/command serial_servo_bridge/msg/ServoCommand "{mode: 1, servo_id: 1, value: 0.0}"
```

如果需要持续发布（例如每秒 10 次）：

```bash
ros2 topic pub -r 10 /servo/command serial_servo_bridge/msg/ServoCommand "{mode: 0, servo_id: 1, value: -30.0}"
```

## 5. 发送限位

节点会在发送串口前做范围校验，超限命令直接丢弃（不会发送到单片机）：

- 位置模式（`mode=0`）默认允许 `[-70, 0]` 度
- 速度模式（`mode=1`）默认允许 `[-5, 5]`

可通过参数调整：

- `pos_min_deg`
- `pos_max_deg`
- `speed_min`
- `speed_max`

## 6. 查看状态

```bash
ros2 topic echo /servo/status
ros2 topic echo /servo/status_raw
```

`/servo/status` 会尝试解析 `AT+Angle,...` / `AT+Pos,...` / `AT+Speed,...` 结构（同时兼容大写命令），解析失败时 `parsed=false`，但 `raw` 仍会保留完整原始行。

## 7. RViz 同步

`status_to_joint_state_bridge_node` 默认映射关系如下：

- 硬件角度：`-70` 到 `0`（度）
- 关节角度：`-1.222` 到 `0`（`gear_drive_joint`，弧度）

如果你要在 RViz 里显示真实硬件反馈，请关闭模型 launch 里的 `joint_state_publisher`，避免两个节点同时发布 `/joint_states`：

```bash
ros2 launch model display_gripper.launch.py
```

如需改回 GUI 手动拖动关节（仅用于仿真演示），可显式开启：

```bash
ros2 launch model display_gripper.launch.py use_joint_state_publisher:=true use_joint_state_gui:=true
```
