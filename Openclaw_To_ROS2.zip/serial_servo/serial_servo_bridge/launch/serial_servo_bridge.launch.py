from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description() -> LaunchDescription:
    return LaunchDescription(
        [
            DeclareLaunchArgument("port", default_value="/dev/ttyUSB0"),
            DeclareLaunchArgument("baud_rate", default_value="115200"),
            DeclareLaunchArgument("pos_min_deg", default_value="-70.0"),
            DeclareLaunchArgument("pos_max_deg", default_value="0.0"),
            DeclareLaunchArgument("speed_min", default_value="-5.0"),
            DeclareLaunchArgument("speed_max", default_value="5.0"),
            DeclareLaunchArgument("enable_status_joint_state_bridge", default_value="true"),
            DeclareLaunchArgument("status_topic", default_value="servo/status"),
            DeclareLaunchArgument("joint_states_topic", default_value="joint_states"),
            DeclareLaunchArgument("connect_service", default_value="servo/connect"),
            DeclareLaunchArgument("disconnect_service", default_value="servo/disconnect"),
            DeclareLaunchArgument("joint_name", default_value="gear_drive_joint"),
            DeclareLaunchArgument("target_servo_id", default_value="1"),
            DeclareLaunchArgument("hardware_min_deg", default_value="-70.0"),
            DeclareLaunchArgument("hardware_max_deg", default_value="0.0"),
            DeclareLaunchArgument("joint_min_rad", default_value="-1.222"),
            DeclareLaunchArgument("joint_max_rad", default_value="0.0"),
            Node(
                package="serial_servo_bridge",
                executable="serial_servo_bridge_node",
                name="serial_servo_bridge",
                output="screen",
                parameters=[
                    {
                        "port": LaunchConfiguration("port"),
                        "baud_rate": LaunchConfiguration("baud_rate"),
                        "pos_min_deg": LaunchConfiguration("pos_min_deg"),
                        "pos_max_deg": LaunchConfiguration("pos_max_deg"),
                        "speed_min": LaunchConfiguration("speed_min"),
                        "speed_max": LaunchConfiguration("speed_max"),
                        "connect_service": LaunchConfiguration("connect_service"),
                        "disconnect_service": LaunchConfiguration("disconnect_service"),
                    }
                ],
            ),
            Node(
                package="serial_servo_bridge",
                executable="status_to_joint_state_bridge_node",
                name="status_to_joint_state_bridge",
                output="screen",
                condition=IfCondition(LaunchConfiguration("enable_status_joint_state_bridge")),
                parameters=[
                    {
                        "status_topic": LaunchConfiguration("status_topic"),
                        "joint_states_topic": LaunchConfiguration("joint_states_topic"),
                        "joint_name": LaunchConfiguration("joint_name"),
                        "target_servo_id": LaunchConfiguration("target_servo_id"),
                        "hardware_min_deg": LaunchConfiguration("hardware_min_deg"),
                        "hardware_max_deg": LaunchConfiguration("hardware_max_deg"),
                        "joint_min_rad": LaunchConfiguration("joint_min_rad"),
                        "joint_max_rad": LaunchConfiguration("joint_max_rad"),
                    }
                ],
            ),
        ]
    )
