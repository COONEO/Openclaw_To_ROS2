#ifndef SERIAL_SERVO_BRIDGE__SERIAL_SERVO_BRIDGE_NODE_HPP_
#define SERIAL_SERVO_BRIDGE__SERIAL_SERVO_BRIDGE_NODE_HPP_

#include <termios.h>

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <mutex>
#include <optional>
#include <string>
#include <thread>

#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "std_srvs/srv/trigger.hpp"

#include "serial_servo_bridge/msg/servo_command.hpp"
#include "serial_servo_bridge/msg/servo_status.hpp"

namespace serial_servo_bridge
{

class SerialServoBridgeNode : public rclcpp::Node
{
public:
  explicit SerialServoBridgeNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());
  ~SerialServoBridgeNode() override;

private:
  void controlCallback(const msg::ServoCommand::SharedPtr msg);
  void connectSerialCallback(
    const std::shared_ptr<std_srvs::srv::Trigger::Request> request,
    std::shared_ptr<std_srvs::srv::Trigger::Response> response);
  void disconnectSerialCallback(
    const std::shared_ptr<std_srvs::srv::Trigger::Request> request,
    std::shared_ptr<std_srvs::srv::Trigger::Response> response);
  void ioLoop();

  bool openSerialPort();
  void closeSerialPort();
  bool writeAll(const std::string & data);

  void enqueueWrite(std::string data);
  bool dequeueWrite(std::string & data);

  void handleIncomingData(const char * data, std::size_t size);
  void processIncomingLine(std::string line);
  bool parseStatusLine(const std::string & line, msg::ServoStatus & status_msg) const;

  static std::optional<speed_t> baudToConstant(int baud_rate);
  static std::string trim(const std::string & text);

  // 串口与协议参数（通过 ROS 参数配置）
  std::string port_;
  int baud_rate_;
  int read_poll_timeout_ms_;
  int reconnect_interval_ms_;
  int value_precision_;
  std::size_t max_line_length_;
  std::string line_ending_;
  double pos_min_deg_;
  double pos_max_deg_;
  double speed_min_;
  double speed_max_;

  // IO 线程生命周期控制
  std::atomic<bool> running_;
  std::atomic<bool> connection_enabled_;
  std::thread io_thread_;

  // 串口句柄与接收缓存
  int serial_fd_;
  std::string rx_buffer_;

  // 发送队列：订阅回调入队，IO 线程出队并写串口
  std::mutex tx_mutex_;
  std::deque<std::string> tx_queue_;

  // ROS 通信接口
  rclcpp::Subscription<msg::ServoCommand>::SharedPtr command_sub_;
  rclcpp::Publisher<msg::ServoStatus>::SharedPtr status_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr raw_status_pub_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr connect_serial_service_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr disconnect_serial_service_;
};

}  // namespace serial_servo_bridge

#endif  // SERIAL_SERVO_BRIDGE__SERIAL_SERVO_BRIDGE_NODE_HPP_
