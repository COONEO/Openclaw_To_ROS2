#include <algorithm>
#include <cmath>
#include <functional>
#include <limits>
#include <string>
#include <utility>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joint_state.hpp"

#include "serial_servo_bridge/msg/servo_status.hpp"

namespace serial_servo_bridge
{
namespace msg = serial_servo_bridge::msg;

class StatusToJointStateBridgeNode : public rclcpp::Node
{
public:
  StatusToJointStateBridgeNode()
  : Node("status_to_joint_state_bridge")
  {
    status_topic_ = declare_parameter<std::string>("status_topic", "servo/status");
    joint_states_topic_ = declare_parameter<std::string>("joint_states_topic", "joint_states");
    joint_name_ = declare_parameter<std::string>("joint_name", "gear_drive_joint");
    target_servo_id_ = declare_parameter<int>("target_servo_id", 1);
    hardware_min_deg_ = declare_parameter<double>("hardware_min_deg", -70.0);
    hardware_max_deg_ = declare_parameter<double>("hardware_max_deg", 0.0);
    joint_min_rad_ = declare_parameter<double>("joint_min_rad", -1.222);
    joint_max_rad_ = declare_parameter<double>("joint_max_rad", 0.0);
    require_parsed_ = declare_parameter<bool>("require_parsed", true);
    accept_mode_pos_only_ = declare_parameter<bool>("accept_mode_pos_only", true);
    clamp_input_ = declare_parameter<bool>("clamp_input", true);

    if (hardware_min_deg_ > hardware_max_deg_) {
      std::swap(hardware_min_deg_, hardware_max_deg_);
      RCLCPP_WARN(
        get_logger(), "hardware_min_deg > hardware_max_deg, swapped to [%.3f, %.3f]",
        hardware_min_deg_, hardware_max_deg_);
    }
    if (joint_min_rad_ > joint_max_rad_) {
      std::swap(joint_min_rad_, joint_max_rad_);
      RCLCPP_WARN(
        get_logger(), "joint_min_rad > joint_max_rad, swapped to [%.3f, %.3f]",
        joint_min_rad_, joint_max_rad_);
    }
    if (!std::isfinite(hardware_min_deg_) || !std::isfinite(hardware_max_deg_) ||
      !std::isfinite(joint_min_rad_) || !std::isfinite(joint_max_rad_))
    {
      throw std::runtime_error("Invalid mapping parameters: non-finite range value.");
    }
    if (std::abs(hardware_max_deg_ - hardware_min_deg_) < 1e-9) {
      throw std::runtime_error("Invalid mapping parameters: hardware range is zero.");
    }

    const auto latest_only_qos = rclcpp::QoS(rclcpp::KeepLast(1));
    status_sub_ = create_subscription<msg::ServoStatus>(
      status_topic_, latest_only_qos,
      std::bind(&StatusToJointStateBridgeNode::statusCallback, this, std::placeholders::_1));
    joint_states_pub_ = create_publisher<sensor_msgs::msg::JointState>(
      joint_states_topic_, latest_only_qos);

    RCLCPP_INFO(
      get_logger(),
      "Status->JointState bridge started. status_topic=%s joint_states_topic=%s joint_name=%s "
      "servo_id=%d mapping_deg=[%.3f, %.3f] mapping_rad=[%.3f, %.3f]",
      status_topic_.c_str(), joint_states_topic_.c_str(), joint_name_.c_str(), target_servo_id_,
      hardware_min_deg_, hardware_max_deg_, joint_min_rad_, joint_max_rad_);
  }

private:
  static constexpr double kEmaAlpha = 0.20;

  static double mapLinear(
    const double value,
    const double in_min,
    const double in_max,
    const double out_min,
    const double out_max)
  {
    const double ratio = (value - in_min) / (in_max - in_min);
    return out_min + ratio * (out_max - out_min);
  }

  void statusCallback(const msg::ServoStatus::SharedPtr status_msg)
  {
    if (require_parsed_ && !status_msg->parsed) {
      return;
    }
    if (accept_mode_pos_only_ && status_msg->mode != msg::ServoStatus::MODE_POS) {
      return;
    }
    if (status_msg->servo_id != static_cast<uint16_t>(target_servo_id_)) {
      return;
    }
    if (!std::isfinite(status_msg->value)) {
      RCLCPP_WARN_THROTTLE(
        get_logger(), *get_clock(), 3000, "Ignore status with non-finite value from servo_id=%u",
        status_msg->servo_id);
      return;
    }

    double angle_deg = static_cast<double>(status_msg->value);
    if (clamp_input_) {
      angle_deg = std::clamp(angle_deg, hardware_min_deg_, hardware_max_deg_);
    } else if (angle_deg < hardware_min_deg_ || angle_deg > hardware_max_deg_) {
      return;
    }

    double joint_rad = mapLinear(
      angle_deg, hardware_min_deg_, hardware_max_deg_, joint_min_rad_, joint_max_rad_);
    joint_rad = std::clamp(joint_rad, joint_min_rad_, joint_max_rad_);
    if (!ema_initialized_) {
      ema_joint_rad_ = joint_rad;
      ema_initialized_ = true;
    } else {
      ema_joint_rad_ = (kEmaAlpha * joint_rad) + ((1.0 - kEmaAlpha) * ema_joint_rad_);
      ema_joint_rad_ = std::clamp(ema_joint_rad_, joint_min_rad_, joint_max_rad_);
    }
    joint_rad = ema_joint_rad_;

    sensor_msgs::msg::JointState joint_state_msg;
    joint_state_msg.header.stamp = status_msg->stamp;
    joint_state_msg.name.emplace_back(joint_name_);
    joint_state_msg.position.emplace_back(joint_rad);

    joint_states_pub_->publish(joint_state_msg);
  }

  std::string status_topic_;
  std::string joint_states_topic_;
  std::string joint_name_;
  int target_servo_id_{1};
  double hardware_min_deg_{-70.0};
  double hardware_max_deg_{0.0};
  double joint_min_rad_{-1.222};
  double joint_max_rad_{0.0};
  bool require_parsed_{true};
  bool accept_mode_pos_only_{true};
  bool clamp_input_{true};
  bool ema_initialized_{false};
  double ema_joint_rad_{0.0};

  rclcpp::Subscription<msg::ServoStatus>::SharedPtr status_sub_;
  rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr joint_states_pub_;
};

}  // namespace serial_servo_bridge

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<serial_servo_bridge::StatusToJointStateBridgeNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
