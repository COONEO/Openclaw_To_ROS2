#include "rclcpp/rclcpp.hpp"
#include "serial_servo_bridge/serial_servo_bridge_node.hpp"

int main(int argc, char ** argv)
{
  // 标准 ROS2 节点生命周期：初始化 -> 运行 -> 清理
  rclcpp::init(argc, argv);
  auto node = std::make_shared<serial_servo_bridge::SerialServoBridgeNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
