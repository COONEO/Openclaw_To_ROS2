#include "serial_servo_bridge/serial_servo_bridge_node.hpp"

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>

#include <chrono>
#include <cmath>
#include <cstring>
#include <exception>
#include <functional>
#include <iomanip>
#include <limits>
#include <sstream>
#include <string_view>
#include <utility>
#include <vector>

namespace serial_servo_bridge
{
namespace
{

std::vector<std::string> splitCsv(const std::string & text)
{
  // 仅按逗号分段，配合 trim 使用即可满足当前 AT 格式解析
  std::vector<std::string> result;
  std::size_t begin = 0;
  while (begin <= text.size()) {
    const std::size_t comma_pos = text.find(',', begin);
    if (comma_pos == std::string::npos) {
      result.emplace_back(text.substr(begin));
      break;
    }
    result.emplace_back(text.substr(begin, comma_pos - begin));
    begin = comma_pos + 1;
  }
  return result;
}

}  // namespace

SerialServoBridgeNode::SerialServoBridgeNode(const rclcpp::NodeOptions & options)
: Node("serial_servo_bridge", options),
  port_(declare_parameter<std::string>("port", "/dev/ttyUSB0")),
  baud_rate_(declare_parameter<int>("baud_rate", 115200)),
  read_poll_timeout_ms_(declare_parameter<int>("read_poll_timeout_ms", 10)),
  reconnect_interval_ms_(declare_parameter<int>("reconnect_interval_ms", 1000)),
  value_precision_(declare_parameter<int>("value_precision", 1)),
  max_line_length_(static_cast<std::size_t>(declare_parameter<int>("max_line_length", 256))),
  line_ending_(declare_parameter<std::string>("line_ending", "\n")),
  pos_min_deg_(declare_parameter<double>("pos_min_deg", -70.0)),
  pos_max_deg_(declare_parameter<double>("pos_max_deg", 0.0)),
  speed_min_(declare_parameter<double>("speed_min", -5.0)),
  speed_max_(declare_parameter<double>("speed_max", 5.0)),
  running_(true),
  connection_enabled_(declare_parameter<bool>("start_connected", true)),
  serial_fd_(-1)
{
  const auto command_topic = declare_parameter<std::string>("command_topic", "servo/command");
  const auto status_topic = declare_parameter<std::string>("status_topic", "servo/status");
  const auto raw_status_topic = declare_parameter<std::string>("raw_status_topic", "servo/status_raw");
  const auto connect_service = declare_parameter<std::string>("connect_service", "servo/connect");
  const auto disconnect_service = declare_parameter<std::string>("disconnect_service", "servo/disconnect");

  if (line_ending_.empty()) {
    line_ending_ = "\n";
  }
  // 协议要求 AT 指令必须以 '\n' 结束；如果参数未包含换行则自动补齐
  if (line_ending_.find('\n') == std::string::npos) {
    line_ending_.push_back('\n');
    RCLCPP_WARN(get_logger(), "line_ending does not contain newline, append '\\n' automatically.");
  }
  if (value_precision_ < 0) {
    value_precision_ = 0;
  }
  if (value_precision_ > 6) {
    value_precision_ = 6;
  }
  if (pos_min_deg_ > pos_max_deg_) {
    std::swap(pos_min_deg_, pos_max_deg_);
    RCLCPP_WARN(
      get_logger(), "pos_min_deg > pos_max_deg, swap automatically. range=[%.3f, %.3f]",
      pos_min_deg_, pos_max_deg_);
  }
  if (speed_min_ > speed_max_) {
    std::swap(speed_min_, speed_max_);
    RCLCPP_WARN(
      get_logger(), "speed_min > speed_max, swap automatically. range=[%.3f, %.3f]",
      speed_min_, speed_max_);
  }

  const auto latest_only_qos = rclcpp::QoS(rclcpp::KeepLast(1));

  command_sub_ = create_subscription<msg::ServoCommand>(
    command_topic,
    latest_only_qos,
    std::bind(&SerialServoBridgeNode::controlCallback, this, std::placeholders::_1));

  status_pub_ = create_publisher<msg::ServoStatus>(status_topic, latest_only_qos);
  raw_status_pub_ = create_publisher<std_msgs::msg::String>(raw_status_topic, rclcpp::QoS(50));
  connect_serial_service_ = create_service<std_srvs::srv::Trigger>(
    connect_service,
    std::bind(
      &SerialServoBridgeNode::connectSerialCallback, this, std::placeholders::_1,
      std::placeholders::_2));
  disconnect_serial_service_ = create_service<std_srvs::srv::Trigger>(
    disconnect_service,
    std::bind(
      &SerialServoBridgeNode::disconnectSerialCallback, this, std::placeholders::_1,
      std::placeholders::_2));

  io_thread_ = std::thread(&SerialServoBridgeNode::ioLoop, this);

  RCLCPP_INFO(
    get_logger(),
    "SerialServoBridgeNode started. port=%s baud=%d command_topic=%s status_topic=%s "
    "connect_service=%s disconnect_service=%s start_connected=%s",
    port_.c_str(), baud_rate_, command_topic.c_str(), status_topic.c_str(), connect_service.c_str(),
    disconnect_service.c_str(), connection_enabled_.load() ? "true" : "false");
}

SerialServoBridgeNode::~SerialServoBridgeNode()
{
  running_.store(false);
  if (io_thread_.joinable()) {
    io_thread_.join();
  }
  closeSerialPort();
}

void SerialServoBridgeNode::controlCallback(const msg::ServoCommand::SharedPtr msg)
{
  if (!connection_enabled_.load()) {
    RCLCPP_WARN_THROTTLE(
      get_logger(), *get_clock(), 3000,
      "Ignore command while serial is disconnected. Use connect service first.");
    return;
  }

  // ROS 控制消息 mode -> 协议字段 Pos/Speed
  std::string mode;
  switch (msg->mode) {
    case msg::ServoCommand::MODE_POS:
      if (msg->value < pos_min_deg_ || msg->value > pos_max_deg_) {
        RCLCPP_WARN(
          get_logger(),
          "Ignore position command: value=%.3f out of range [%.3f, %.3f], servo_id=%u",
          msg->value, pos_min_deg_, pos_max_deg_, msg->servo_id);
        return;
      }
      mode = "Pos";
      break;
    case msg::ServoCommand::MODE_SPEED:
      if (msg->value < speed_min_ || msg->value > speed_max_) {
        RCLCPP_WARN(
          get_logger(),
          "Ignore speed command: value=%.3f out of range [%.3f, %.3f], servo_id=%u",
          msg->value, speed_min_, speed_max_, msg->servo_id);
        return;
      }
      mode = "Speed";
      break;
    default:
      RCLCPP_WARN(get_logger(), "Ignore command: unsupported mode=%u", msg->mode);
      return;
  }
  if (!std::isfinite(msg->value)) {
    RCLCPP_WARN(get_logger(), "Ignore command: non-finite value=%f, servo_id=%u", msg->value, msg->servo_id);
    return;
  }

  std::ostringstream command;
  // 按约定拼接 AT 指令：AT+Pos,<id>,<value>\n 或 AT+Speed,<id>,<value>\n
  command << "AT+" << mode << "," << msg->servo_id << ",";
  command << std::fixed << std::setprecision(value_precision_) << msg->value;
  command << line_ending_;

  enqueueWrite(command.str());
}

void SerialServoBridgeNode::connectSerialCallback(
  const std::shared_ptr<std_srvs::srv::Trigger::Request> /*request*/,
  std::shared_ptr<std_srvs::srv::Trigger::Response> response)
{
  connection_enabled_.store(true);
  response->success = true;
  response->message = "Serial connect requested.";
}

void SerialServoBridgeNode::disconnectSerialCallback(
  const std::shared_ptr<std_srvs::srv::Trigger::Request> /*request*/,
  std::shared_ptr<std_srvs::srv::Trigger::Response> response)
{
  connection_enabled_.store(false);

  {
    std::lock_guard<std::mutex> lock(tx_mutex_);
    tx_queue_.clear();
  }

  response->success = true;
  response->message = "Serial disconnect requested.";
}

void SerialServoBridgeNode::ioLoop()
{
  constexpr std::size_t kReadBufferSize = 256;
  char read_buffer[kReadBufferSize];

  // 单独 IO 线程：负责“持续接收 + 发送队列落串口 + 异常自动重连”
  while (running_.load() && rclcpp::ok()) {
    if (!connection_enabled_.load()) {
      if (serial_fd_ >= 0) {
        closeSerialPort();
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(50));
      continue;
    }

    if (serial_fd_ < 0) {
      if (!openSerialPort()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(reconnect_interval_ms_));
        continue;
      }
    }

    pollfd poll_fd{};
    poll_fd.fd = serial_fd_;
    poll_fd.events = POLLIN;

    const int poll_result = ::poll(&poll_fd, 1, read_poll_timeout_ms_);
    if (poll_result < 0) {
      if (errno != EINTR) {
        RCLCPP_ERROR(get_logger(), "poll() failed: %s", std::strerror(errno));
        closeSerialPort();
        std::this_thread::sleep_for(std::chrono::milliseconds(reconnect_interval_ms_));
      }
      continue;
    }

    if ((poll_fd.revents & POLLIN) != 0) {
      const ssize_t read_size = ::read(serial_fd_, read_buffer, sizeof(read_buffer));
      if (read_size > 0) {
        handleIncomingData(read_buffer, static_cast<std::size_t>(read_size));
      } else if (read_size == 0) {
        RCLCPP_WARN(get_logger(), "Serial port closed by peer, reconnecting...");
        closeSerialPort();
        continue;
      } else if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
        RCLCPP_ERROR(get_logger(), "read() failed: %s", std::strerror(errno));
        closeSerialPort();
        continue;
      }
    }

    if ((poll_fd.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0) {
      RCLCPP_WARN(get_logger(), "Serial port event error (revents=%d), reconnecting...", poll_fd.revents);
      closeSerialPort();
      continue;
    }

    std::string tx_data;
    while (dequeueWrite(tx_data)) {
      if (!writeAll(tx_data)) {
        closeSerialPort();
        break;
      }
    }
  }
}

bool SerialServoBridgeNode::openSerialPort()
{
  const int fd = ::open(port_.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
  if (fd < 0) {
    RCLCPP_ERROR_THROTTLE(
      get_logger(), *get_clock(), 5000, "Failed to open %s: %s", port_.c_str(), std::strerror(errno));
    return false;
  }

  termios tty{};
  if (::tcgetattr(fd, &tty) != 0) {
    RCLCPP_ERROR(get_logger(), "tcgetattr() failed: %s", std::strerror(errno));
    ::close(fd);
    return false;
  }

  const auto baud_constant = baudToConstant(baud_rate_);
  if (!baud_constant.has_value()) {
    RCLCPP_ERROR(get_logger(), "Unsupported baud rate: %d", baud_rate_);
    ::close(fd);
    return false;
  }

  // 串口设置为 raw，避免行缓冲和终端回显等干扰二进制/文本协议
  ::cfmakeraw(&tty);
  tty.c_cflag |= static_cast<unsigned>(CLOCAL | CREAD);
  tty.c_cflag &= static_cast<unsigned>(~CRTSCTS);
  tty.c_cflag &= static_cast<unsigned>(~CSTOPB);
  tty.c_cflag &= static_cast<unsigned>(~PARENB);
  tty.c_cc[VMIN] = 0;
  tty.c_cc[VTIME] = 0;

  if (::cfsetispeed(&tty, *baud_constant) != 0 || ::cfsetospeed(&tty, *baud_constant) != 0) {
    RCLCPP_ERROR(get_logger(), "Failed to set baud rate: %s", std::strerror(errno));
    ::close(fd);
    return false;
  }

  if (::tcsetattr(fd, TCSANOW, &tty) != 0) {
    RCLCPP_ERROR(get_logger(), "tcsetattr() failed: %s", std::strerror(errno));
    ::close(fd);
    return false;
  }

  ::tcflush(fd, TCIOFLUSH);

  serial_fd_ = fd;
  rx_buffer_.clear();
  RCLCPP_INFO(get_logger(), "Serial port connected: %s @ %d", port_.c_str(), baud_rate_);
  return true;
}

void SerialServoBridgeNode::closeSerialPort()
{
  if (serial_fd_ >= 0) {
    ::close(serial_fd_);
    serial_fd_ = -1;
  }
}

bool SerialServoBridgeNode::writeAll(const std::string & data)
{
  // 非阻塞串口下保证整帧写完，处理中断和 EAGAIN
  std::size_t written_total = 0;
  while (written_total < data.size() && running_.load()) {
    const ssize_t written = ::write(
      serial_fd_, data.data() + static_cast<std::ptrdiff_t>(written_total), data.size() - written_total);
    if (written > 0) {
      written_total += static_cast<std::size_t>(written);
      continue;
    }

    if (written < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
      pollfd poll_fd{};
      poll_fd.fd = serial_fd_;
      poll_fd.events = POLLOUT;
      const int poll_result = ::poll(&poll_fd, 1, read_poll_timeout_ms_);
      if (poll_result >= 0) {
        continue;
      }
      if (errno == EINTR) {
        continue;
      }
      RCLCPP_ERROR(get_logger(), "poll(POLLOUT) failed: %s", std::strerror(errno));
      return false;
    }

    if (written < 0 && errno == EINTR) {
      continue;
    }

    RCLCPP_ERROR(get_logger(), "write() failed: %s", std::strerror(errno));
    return false;
  }

  return true;
}

void SerialServoBridgeNode::enqueueWrite(std::string data)
{
  {
    std::lock_guard<std::mutex> lock(tx_mutex_);
    tx_queue_.emplace_back(std::move(data));
  }
}

bool SerialServoBridgeNode::dequeueWrite(std::string & data)
{
  std::lock_guard<std::mutex> lock(tx_mutex_);
  if (tx_queue_.empty()) {
    return false;
  }
  data = std::move(tx_queue_.front());
  tx_queue_.pop_front();
  return true;
}

void SerialServoBridgeNode::handleIncomingData(const char * data, std::size_t size)
{
  rx_buffer_.append(data, size);

  // 按 '\n' 进行帧切分；兼容 "\r\n"
  while (true) {
    const std::size_t line_end = rx_buffer_.find('\n');
    if (line_end == std::string::npos) {
      break;
    }

    std::string line = rx_buffer_.substr(0, line_end);
    rx_buffer_.erase(0, line_end + 1);

    if (!line.empty() && line.back() == '\r') {
      line.pop_back();
    }

    line = trim(line);
    if (!line.empty()) {
      processIncomingLine(std::move(line));
    }
  }

  if (rx_buffer_.size() > max_line_length_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(), *get_clock(), 5000,
      "RX buffer exceeded %zu bytes without newline. Dropping stale bytes.", max_line_length_);
    rx_buffer_.clear();
  }
}

void SerialServoBridgeNode::processIncomingLine(std::string line)
{
  // 原始串口行先无损发布，便于调试
  std_msgs::msg::String raw_msg;
  raw_msg.data = line;
  raw_status_pub_->publish(raw_msg);

  // 同时尝试解析成结构化状态消息，供上层逻辑直接使用
  msg::ServoStatus status_msg;
  status_msg.stamp = now();
  status_msg.raw = std::move(line);
  status_msg.parsed = false;
  status_msg.mode = msg::ServoStatus::MODE_UNKNOWN;
  status_msg.servo_id = 0;
  status_msg.value = 0.0F;

  status_msg.parsed = parseStatusLine(status_msg.raw, status_msg);
  status_pub_->publish(status_msg);
}

bool SerialServoBridgeNode::parseStatusLine(
  const std::string & line,
  msg::ServoStatus & status_msg) const
{
  // 兼容输入：AT+Angle,1,-30.0 / Angle,1,-30.0（位置）
  // 同时保留历史格式：AT+Pos,... / Pos,...
  std::string payload = trim(line);
  if (payload.rfind("AT+", 0) == 0) {
    payload = payload.substr(3);
  }

  const std::vector<std::string> fields = splitCsv(payload);
  if (fields.size() != 3) {
    return false;
  }

  const std::string mode = trim(fields[0]);
  if (mode == "Pos" || mode == "POS" || mode == "Angle" || mode == "ANGLE") {
    status_msg.mode = msg::ServoStatus::MODE_POS;
  } else if (mode == "Speed" || mode == "SPEED") {
    status_msg.mode = msg::ServoStatus::MODE_SPEED;
  } else {
    return false;
  }

  try {
    const unsigned long servo_id = std::stoul(trim(fields[1]));
    if (servo_id > std::numeric_limits<uint16_t>::max()) {
      return false;
    }
    status_msg.servo_id = static_cast<uint16_t>(servo_id);

    status_msg.value = std::stof(trim(fields[2]));
  } catch (const std::exception &) {
    return false;
  }

  return true;
}

std::optional<speed_t> SerialServoBridgeNode::baudToConstant(int baud_rate)
{
  switch (baud_rate) {
    case 9600:
      return B9600;
    case 19200:
      return B19200;
    case 38400:
      return B38400;
    case 57600:
      return B57600;
    case 115200:
      return B115200;
#ifdef B230400
    case 230400:
      return B230400;
#endif
#ifdef B460800
    case 460800:
      return B460800;
#endif
#ifdef B921600
    case 921600:
      return B921600;
#endif
    default:
      return std::nullopt;
  }
}

std::string SerialServoBridgeNode::trim(const std::string & text)
{
  constexpr std::string_view whitespace = " \t\r\n";
  const auto begin = text.find_first_not_of(whitespace);
  if (begin == std::string::npos) {
    return std::string();
  }
  const auto end = text.find_last_not_of(whitespace);
  return text.substr(begin, end - begin + 1);
}

}  // namespace serial_servo_bridge
